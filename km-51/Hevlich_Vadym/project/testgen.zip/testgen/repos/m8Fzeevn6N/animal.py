class Animal(object):
    def __init__(self, species):
        self.species = species

    def get_species(self):
        return self.species
