import os
import random
import re
import string
import sys

import auger
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, DetailView
from django.conf import settings

from git import Repo as GitRepo

from .forms import AddRepoForm
from .models import Repo


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('main')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})


class MainView(CreateView, ListView):
    template_name = 'main.html'
    success_url = reverse_lazy('main')
    form_class = AddRepoForm

    def get_queryset(self):
        return Repo.objects.filter(user=self.request.user)

    def form_valid(self, form):
        repo = form.save(commit=False)
        repo.user = self.request.user

        repo_dir = ''.join(random.choice(string.ascii_letters + string.digits)
                           for _ in range(10))
        repo.relative_dir = repo_dir

        repo.save()

        GitRepo.clone_from(repo.deep_link, os.path.join(settings.REPOS_DIR, repo_dir))
        return redirect(self.success_url)


class RepoView(DetailView):
    model = Repo
    template_name = 'repo.html'
    success_url = reverse_lazy('main')

    @staticmethod
    def make_import(name):
        mod = __import__(name)
        class_name = getattr(mod, name.split('.')[-1])
        return class_name

    def findfiles(self, path, dir_name):
        for path, dirs, files in os.walk(path):
            for filename in files:
                if '.py' in filename:
                    fullpath = os.path.join(path, filename)
                    with open(fullpath, 'r') as f:
                        context_lines = f.readlines()
                        for line in context_lines:
                            if '# test_magic' in line:
                                mod_name = fullpath.split('/')[-2:]
                                last_mod_name = mod_name[-1].split('.')[0]
                                python_mod_name = '.'.join(mod_name[:-1])
                                python_mod_name = python_mod_name + '.' + last_mod_name

                                sys.path.insert(0, '/'.join(fullpath.split('/')[:-2]))

                                class_name = line.lstrip('class ').split('(')[0]

                                module = self.make_import(python_mod_name + '.' + class_name)
                                return module

    def get(self, request, *args, **kwargs):
        if 'remove' in request.GET.keys():
            self.get_object().delete()
            return redirect(self.success_url)
        elif 'generate' in request.GET.keys():
            module = self.findfiles(
                os.path.join(settings.REPOS_DIR, self.get_object().relative_dir), self.get_object().relative_dir)

            with auger.magic([module]):
                module.main()

        elif 'update' in request.GET.keys():
            repo = GitRepo(os.path.join(settings.REPOS_DIR, self.get_object().relative_dir))
            o = repo.remotes.origin
            o.pull()

        return super().get(request, *args, **kwargs)
