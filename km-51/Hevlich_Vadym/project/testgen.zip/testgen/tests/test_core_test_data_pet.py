import core.test_data.animal
from core.test_data.animal import Animal
import core.test_data.pet
from core.test_data.pet import Animal
from core.test_data.pet import Pet
from mock import patch
import unittest


class PetTest(unittest.TestCase):
    @patch.object(Animal, 'get_species')
    def test___str__(self, mock_get_species):
        mock_get_species.return_value = 'Parrot'
        self.assertEqual(
            Pet.__str__(self=<core.test_data.pet.Pet object at 0x7f40dbea87b8>),
            'Polly is a Parrot'
        )


    def test_create_pet(self):
        self.assertIsInstance(
            core.test_data.pet.create_pet(name='Polly',species='Parrot'),
            core.test_data.pet.Pet
        )


    def test_get_name(self):
        self.assertEqual(
            Pet.get_name(self=<core.test_data.pet.Pet object at 0x7f40dbea87b8>),
            'Polly'
        )


if __name__ == "__main__":
    unittest.main()
